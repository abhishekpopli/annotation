package com.baeldung.annotation.processor;

import org.graalvm.compiler.graph.Node;

import java.lang.annotation.*;
import java.lang.reflect.Array;
import java.util.List;

@Target(ElementType.FIELD)
@Retention(RetentionPolicy.SOURCE)
public @interface BuilderProperty {

    String param1() default "abhishek";

}
