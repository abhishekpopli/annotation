package com.baeldung.annotation;

import com.baeldung.annotation.processor.BuilderProperty;
import com.baeldung.annotation.processor.Myenum;

import java.lang.reflect.Array;
import java.util.Arrays;

public class Person {

    @BuilderProperty(param1 = "popli")
    private int age;

    @BuilderProperty
    private String name;


    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
