package com.baeldung.annotation.processor;

import java.io.*;
import java.util.*;
import java.util.stream.Collectors;
import javax.annotation.processing.*;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.ElementKind;
import javax.lang.model.element.TypeElement;
import javax.lang.model.element.VariableElement;
import javax.lang.model.type.ExecutableType;
import javax.lang.model.type.MirroredTypeException;
import javax.lang.model.type.TypeMirror;
import javax.lang.model.util.ElementFilter;
import javax.tools.Diagnostic;
import javax.tools.JavaFileObject;

import com.google.auto.service.AutoService;

@SupportedAnnotationTypes("com.baeldung.annotation.processor.BuilderProperty")
@SupportedSourceVersion(SourceVersion.RELEASE_8)
@AutoService(Processor.class)
public class BuilderProcessor extends AbstractProcessor {

    @Override
    public boolean process(Set<? extends TypeElement> annotations, RoundEnvironment roundEnv) {
        ArrayList<String> activitiesWithPackage = new ArrayList<>();
        for (TypeElement typeElement : annotations) {
            for (Element element : roundEnv.getElementsAnnotatedWith(typeElement)) {
                if (element.getKind() == ElementKind.FIELD) {

                    String fullTypeClassName = element.getSimpleName().toString();
                    activitiesWithPackage.add(fullTypeClassName);
                    BuilderProperty anno = element.getAnnotation(BuilderProperty.class);
//                    TypeMirror value = null;
//                    if (anno != null) {
//                        try {
//                            anno.enumClass();
//                        } catch (MirroredTypeException mte) {
//                            value = mte.getTypeMirror();
//                        }
//                    }
////                    for (Enum e : value.getAnnotation(Myenum.class).enumClassenumClassenumClass().getEnumConstants()) {
//                    for (Enum e : value.g) {
//                          for(Object obj: myclass.getEnumConstants()) {
                        activitiesWithPackage.add(anno.param1());
//                    }

                }
            }
        }

        try {
            writeBuilderFile(activitiesWithPackage);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return true;
    }

    private void writeBuilderFile(List<String> activitiesWithPackage ) throws IOException {

        String packageName = "com.baeldung.annotation";
        String builderClassName = "PersonBuilder";

        ObjectOutputStream printWriter =  new ObjectOutputStream(new FileOutputStream("output.txt",true));
        PrintWriter printWriter2 =  new PrintWriter(new FileOutputStream("output2.txt", true));

        printWriter.writeObject(activitiesWithPackage);
        for(String s: activitiesWithPackage)
        {printWriter2.println(s);}
        printWriter.close();
        printWriter2.close();

        ArrayList<String> newList = new ArrayList<>();
        try {
            FileInputStream fileIn = new FileInputStream("output.txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            newList = (ArrayList<String>) in.readObject();
            for (String name : newList) {
                printWriter2.println(name);
            }
            in.close();
            fileIn.close();
            printWriter2.close();
        } catch (IOException i) {
            i.printStackTrace();
            return;
        } catch (ClassNotFoundException c) {
            System.out.println("Employee class not found");
            c.printStackTrace();
            return;
        }
//        JavaFileObject builderFile = processingEnv.getFiler().createSourceFile(builderClassName);
//        try (PrintWriter out = new PrintWriter(builderFile.openWriter())) {
//
//            if (packageName != null) {
//                out.print("package ");
//                out.print(packageName);
//                out.println(";");
//                out.println();
//            }
//
//            out.print("public class ");
//            out.print(builderClassName);
//            out.println(" {");
//            out.println();
//
//            for (String str : activitiesWithPackage) {
//                out.print( "//");
//                out.println(str);
//                out.println();
//            }
//
//            out.println("}");
//
//        }
    }

}
