package com.baeldung.annotation.processor;

public enum Myenum{
    CreditCard,DebitCard;
Myenum[] a = Myenum.values();
    public  Myenum[] mymethod() {
        return Myenum.values();
    }
}
